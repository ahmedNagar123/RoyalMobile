package com.example.roylmobile.base;

public interface CallBack {
    void showLayout(int v);
}

