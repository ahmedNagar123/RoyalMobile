package com.example.roylmobile.utils;

public class Constants {

    //    public static final String ALIGN_CENTER="center";
//    public static final String EG_REGEX = "(^01\\d{9})";
//    public static final String SAUDI_REGEX = "(^05\\d{8})";
//    public static final String POLICY_ENG = "https://merlinedu.com/en/privacy-policy/";
//    public static final String POLICY_AR = "https://merlinedu.com/ar/privacy-policy/";
    public static final String Token = "1a01c2ba2237b1bc1de62f82addf3538360cd0a8de86692c";


//    public static final String LOCAL_PREF="local";
//    public static final int REPORTS_OF_PERIOD = 0;
//    public static final int REPORTS_ALL_CATEGORIES = 1;
//    public static final int REPORTS_ONE_CATEGORY = 2;


//    final static String SETTINGS_USER_ID = "user_id";

    public static final String DISPLAY_DATE_FORMAT = "dd-MM-yyyy";


//
//    public static final class ServiceConstants{
//
//
//
//        public static int EG = 0;
//
//    }
//
//    public static final class DataLists {
//
//
//
//    }
}
